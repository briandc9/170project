CS 170 Fall 2019 Project
Brian Chin
Imam Widodo

## Running the code:
With the cmd prompt in the directory of the code_submission/ folder (you should see files solver.py, input_creator.py, etc... in this folder):

### Make sure you have downloaded the following python libraries and are running on Python 3:
- os
- sys
- argparse
- utils
- numpy (we used v1.17.3)
- networkx (we used v2.4)
- matplotlib (for the input creator - we used v3.1.1)

### To run the solver
With your inputs in an inputs/ folder and your outputs in an outputs/ folder:

To solve an input (i.e. "inputs/50.in"), run in cmd prompt:

> python solver.py $input file path$ $output folder path$

(i.e. python solver.py inputs/50.in outputs/)

This will create a file "outputs/50.out" that will contain the solution to your input file problem.


### To run the input creator
To create an input file problem (i.e. "inputs/50.in"), run in cmd prompt:

> python input_creator.py

It will present you with a prompt

> n: $num locations$

Type in the number of locations you want from {50, 100, 200}
(i.e. n: 50)

This will create a file "inputs/50.in" (for 50 locations) that will contain your input file problem.


